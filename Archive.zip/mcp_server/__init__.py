"""SemanticPay MCP Server package."""
